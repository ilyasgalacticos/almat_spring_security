package kz.almat.almatsecurityboot.almatsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmatsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmatsecurityApplication.class, args);
	}

}
