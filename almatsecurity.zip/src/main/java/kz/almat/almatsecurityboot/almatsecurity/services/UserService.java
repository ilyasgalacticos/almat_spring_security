package kz.almat.almatsecurityboot.almatsecurity.services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {



}
