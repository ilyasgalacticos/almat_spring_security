package kz.almat.almatsecurityboot.almatsecurity.controllers;

import kz.almat.almatsecurityboot.almatsecurity.entities.Users;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping(value = {"/", "/index", "/home"})
    public String index(Model model){
        model.addAttribute("CURRENT_USER", getUser());
        return "index";
    }

    @GetMapping(value = "/loginpage")
    public String loginPage(Model model){
        model.addAttribute("CURRENT_USER", getUser());
        return "loginpage";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/profile")
    public String profile(Model model){
        model.addAttribute("CURRENT_USER", getUser());
        return "profile";
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @GetMapping(value = "/adminpanel")
    public String adminPanel(Model model){
        model.addAttribute("CURRENT_USER", getUser());
        return "adminpanel";
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MODERATOR')")
    @GetMapping(value = "/moderatorpanel")
    public String moderatorPanel(Model model){
        model.addAttribute("CURRENT_USER", getUser());
        return "moderatorpanel";
    }

    private Users getUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(!(authentication instanceof AnonymousAuthenticationToken)){
            return (Users) authentication.getPrincipal();
        }
        return null;
    }

}